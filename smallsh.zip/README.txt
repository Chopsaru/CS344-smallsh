copy smallsh.c to flip server and run the following commands in the containing folder to complile and run:
% gcc -o smallsh smallsh.c
% smallsh